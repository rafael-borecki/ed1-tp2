Arquivo zip gerado em: 14/11/2023 15:36:43 
Este arquivo contém todos os casos de teste cadastrados até o momento, disponível apenas para professores/monitores. 
Para alterar um caso de teste acesse o sistema. 
Exercício: TP02 - Big Brother (Trabalho Prático: vale nota)